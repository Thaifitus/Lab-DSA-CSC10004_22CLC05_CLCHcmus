#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>

sem_t mutex;
FILE *fptr = NULL;

/*
Write to file function (thread 1 function)
*/
void write_file(void* file_name) {

	char *w_file = NULL;
	w_file = (char*)file_name;
	// Open text file in writing mode
	fptr = fopen(w_file, "w");
	// Exit if cannot open file
	if(fptr == NULL)
	{
		printf("Cannot open to write file");
		exit(1);
	}

	// Write to file
	fprintf(fptr, "%s", "20127625-Nguyen Truong Hoang Thai");

	// Close file
	fclose(fptr);
	// Wake up reading thread (thread 2)
	sem_post(&mutex);
}

/*
Read from file function (thread 2 function)
*/
void read_file(void* file_name) {
	// Ensure writing file first
	sem_wait(&mutex);

	char* r_file = NULL;
	r_file = (char*)file_name;
	// Open text file in reading mode
	fptr = fopen(r_file, "r");
	// Exit if cannot open file
	if(fptr == NULL)
	{
		printf("Cannot open to read file");
		exit(1);
	}

	char file_content[40];
	// Read file
	fgets(file_content, 40, fptr);
	printf(file_content);

	// Close file
	fclose(fptr);
}

int main()
{
	sem_init(&mutex, 0, 0);
	pthread_t thread1, thread2;
	char* file_name = "text.txt";

	pthread_create(&thread1, NULL, write_file, (void*)file_name);
	pthread_create(&thread2, NULL, read_file, (void*)file_name);

	pthread_join(thread1, NULL);
	pthread_join(thread2, NULL);

	sem_destroy(&mutex);
	return 0;
}