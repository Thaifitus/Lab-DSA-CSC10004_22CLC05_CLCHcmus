#include <iostream>
#include <string.h>

using namespace std;

FILE *fptr = NULL;

/*
Read from file function (thread 2 function)
*/
void read_file() {
    char* r_file = "input1.1.txt";
    // Open text file in reading mode
    fptr = fopen(r_file, "r");
    // Exit if cannot open file
    if(fptr == NULL)
    {
        printf("Cannot open to read file");
        exit(1);
    }

    // Read file
    char file_content[201]; // reading buffer
    int word_count = 0, seq_count = 0; // word count and sequence count
    while(fgets(file_content, sizeof(file_content), fptr))
    {
        printf(file_content);
        for(int i=0; i<strlen(file_content)-1; i++)
        {
            char space = ' ';
            char dot = '.';
            if(file_content[i] == space)
            {
                word_count++;
            }
            else if(file_content[i] == dot && file_content[i+1] == space)
            {
                seq_count++;
                word_count++;
                i++; // not counting space in the next loop
            }
        }
        word_count++;
        seq_count++;
    }

    cout << "So luong tu: " << word_count << endl;
    cout << "So luong cau: " << seq_count;

    // Close file
    fclose(fptr);
}


int main()
{
    read_file();    
    return 0;
}