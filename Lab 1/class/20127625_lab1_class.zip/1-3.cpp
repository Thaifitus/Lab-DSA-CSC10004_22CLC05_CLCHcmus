#include <iostream>
#include <string.h>

using namespace std;

FILE *fptr = NULL;

/*
Write to file function (thread 1 function)
*/
void write_file(void* file_name) {

    char *w_file = NULL;
    w_file = (char*)file_name;
    // Open text file in writing mode
    fptr = fopen(w_file, "w");
    // Exit if cannot open file
    if(fptr == NULL)
    {
        printf("Cannot open to write file");
        exit(1);
    }

    // Write to file
    if(strcmp(w_file, "input1.3.txt")==0)
    {
        char input[100];
        while(cin.getline(input,sizeof(input)))
        {
            fprintf(fptr, "%s\n", input);
        }
    }
    else
    {

    }

    // Close file
    fclose(fptr);
}

/*
Read from file function (thread 2 function)
*/
void read_file(void* file_name) {
    char* r_file = NULL;
    r_file = (char*)file_name;
    // Open text file in reading mode
    fptr = fopen(r_file, "r");
    // Exit if cannot open file
    if(fptr == NULL)
    {
        printf("Cannot open to read file");
        exit(1);
    }

    // Read file
    char file_content[40];
    while(fgets(file_content, sizeof(file_content), fptr))
    {
        printf(file_content);
    }
    // fgets(file_content, 40, fptr);

    // Close file
    fclose(fptr);
}


int main()
{
    char* file_name = "input1.3.txt";
    write_file(file_name);
    // read_file(file_name);    

    return 0;
}