#include <iostream>
#include <stdio.h>
#include <string.h>
#include <algorithm>

using namespace std;

// Randomly generation
void GenerateRandomData(int*& a, int n)
{
	srand((unsigned int)time(NULL));
	for (int i = 0; i < n; i++)
	{
		a[i] = rand()%n;
	}
}

// Ascending generation
void GenerateSortedData(int*& a, int n)
{
	for (int i = 0; i < n; i++)
	{
		a[i] = i;
	}
}

// Descending generation
void GenerateReverseData(int*& a, int n)
{
	for (int i = 0; i < n; i++)
	{
		a[i] = n - 1 - i;
	}
}

void GenerateData(int*& a, int n, int dataType)
{
	switch (dataType)
	{
	case 0:	// randomly
		GenerateRandomData(a, n);
		break;
	case 1:	// ascending
		GenerateSortedData(a, n);
		break;
	case 2:	// descending
		GenerateReverseData(a, n);
		break;
	default:
		cout << "Error";
	}
}

void PrintArray(int* arr, int n)
{
	for(int i = 0; i < n; i++)
	{
		cout << arr[i] << " ";
	}
}

// Quick sort
void qSort(int left, int right, int*& arr)
{
	int i = left, j = right;
	int pivot = arr[(left + right) / 2];

	while (i <= j)
	{
		while (arr[i] < pivot)
			i++;
		while (arr[j] > pivot)
			j--;

		if (i <= j)
		{
			swap(arr[i], arr[j]);
			i++;
			j--;
		}
	}
	if (left < j)
		qSort(left, j, arr);
	if (i < right)
		qSort(i, right, arr);
}

// Heap sort
void Rebuild(int*& arr, int n, int pos)
{
	int k = pos;
	bool isHeap = false;
	while(!isHeap && 2 * k + 1 < n)
	{
		int j = 2 * k + 1;
		if(j + 1 < n && arr[j + 1] < arr[j])
			j++;

		if(arr[k] <= arr[j])
			isHeap = true;
		else
		{
			swap(arr[k], arr[j]);
			k = j;
		}
	}
}
void HeapCons(int*& arr, int n)
{
	int i = (n - 2) / 2;
	while(i >= 0)
	{
		Rebuild(arr, n, i);
		i--;
	}
}
void HeapSort(int*& arr, int n)
{
	int r = n - 1;
	HeapCons(arr, n);
	while(r > 0)
	{
		swap(arr[0], arr[r]);
		Rebuild(arr, r, 0);
		r--;
	}
}

// Merge sort
void Merge(int l, int mid, int r, int arr[])
{
	int nl = mid + 1 - l;
	int nr = r - mid;

	int* larr = new int[nl];
	int* rarr = new int[nr];
	for(int i = 0; i < nl; i++)
		larr[i] = arr[l + i];
	for(int i = 0; i < nr; i++)
		rarr[i] = arr[mid + 1 + i];
	
	int il = 0, ir = 0, k = l;
	while(il < nl && ir < nr)
	{
		if(larr[il] >= rarr[ir])
		{
			arr[k] = larr[il];
			il++;
		}
		else
		{
			arr[k] = rarr[ir];
			ir++;
		}
		k++;
	}
	while(il < nl)
	{
		arr[k] = larr[il];
		il++;
		k++;
	}
	while(ir < nr)
	{
		arr[k] = rarr[ir];
		ir++;
		k++;
	}
}
void MergeSort(int l, int r, int arr[])
{
	if(l >= r)
		return;
	int mid = (r + l) / 2;
	MergeSort(l, mid, arr);
	MergeSort(mid + 1, r, arr);
	Merge(l, mid, r, arr);
}


int main()
{
	// Cau 1
	int n_1 = 0;
	cout << "Nhap vao so luong phan tu n: ";
	cin >> n_1;

	// Quick sort
	int* arr = new int[n_1];
	GenerateData(arr, n_1, 0);

	cout << "Quick sort:\nTruoc khi sort: ";
	PrintArray(arr, n_1);

	qSort(0, n_1 - 1, arr);
	cout << "\nSau khi sort: ";
	PrintArray(arr, n_1);

	// Heap sort
	GenerateData(arr, n_1, 0);
	cout << "\n\nHeap sort:\nTruoc khi sort: ";
	PrintArray(arr, n_1);

	HeapSort(arr, n_1);
	cout << "\nSau khi sort: ";
	PrintArray(arr, n_1);


	// Cau 2
	int m = 0;
	int n = 0;
	cout << "\n\nCau 2\n";
	cout << "Nhap m: ";
	cin >> m;
	cout << "Nhap n: ";
	cin >> n;
	int* a_arr = new int[m];
	int* b_arr = new int [n];

	GenerateData(a_arr, m, 2);
	GenerateData(b_arr, n, 1);
	cout << "\nMang a: ";
	PrintArray(a_arr, m);
	cout << "\nMang b: ";
	PrintArray(b_arr, n);

	int* res = new int[m+n];
	int i_res = 0;
	for(int i = 0; i < m; i++)
		res[i_res++] = a_arr[i];
	for(int i = 0; i < n; i++)
		res[i_res++] = b_arr[i];

	MergeSort(0, m+n-1, res);
	cout << "\nSau khi ket hop va sap xep 2 mang: ";
	PrintArray(res, m+n);

	cout << endl;
	return 0;
}