#include <iostream>
#include <string.h>
#include <stdio.h>

using namespace std;

struct Company{
	char name[201];
	char tax[201];
	char legal_people[201];
	char address[201];
};

struct Node{
	Company data;
	Node* pLeft;
	Node* pRight;
};
Node* createNode(Company input_data)
{
	Node* temp = new Node;
	temp->pLeft = nullptr;
	temp->pRight = nullptr;

	strcpy(temp->data.name, input_data.name);
	strcpy(temp->data.tax, input_data.tax);
	strcpy(temp->data.legal_people, input_data.legal_people);
	strcpy(temp->data.address, input_data.address);
	
	return temp;
}
int Height(Node* pRoot)
{
	if(pRoot == nullptr)
		return 0;

	int lheight = Height(pRoot->pLeft);
	int rheight = Height(pRoot->pRight);
	if(lheight > rheight)
		return lheight + 1;
	else
		return rheight + 1;
}
void RightRotation(Node* &pRoot)
{
	if(pRoot == nullptr || pRoot->pLeft == nullptr && pRoot->pRight == nullptr)
		return;

	Node* temp = pRoot->pLeft;
	pRoot->pLeft = temp->pRight;
	temp->pRight = pRoot;
	pRoot = temp;
}
void LeftRotation(Node* &pRoot)
{
	if(pRoot == nullptr || pRoot->pLeft == nullptr && pRoot->pRight == nullptr)
		return;

	Node* temp = pRoot->pRight;
	pRoot->pRight = temp->pLeft;
	temp->pLeft = pRoot;
	pRoot = temp;
}
void MakeRightHeight(Node* &pRoot)
{
	if(pRoot == nullptr)
		return;

	int diff = Height(pRoot->pLeft) - Height(pRoot->pRight);
	int l, r;
	if(diff >= 2)
	{
		l = Height(pRoot->pLeft->pLeft);
		r = Height(pRoot->pLeft->pRight);
		if(l >= r)
		{
			RightRotation(pRoot);
		}
		else
		{
			LeftRotation(pRoot->pLeft);
			RightRotation(pRoot);
		}
	}
	else if(diff <= -2)
	{
		l = Height(pRoot->pRight->pLeft);
		r = Height(pRoot->pRight->pRight);
		if(r >= l)
		{
			LeftRotation(pRoot);
		}
		else
		{
			RightRotation(pRoot->pRight);
			LeftRotation(pRoot);
		}
	}
}
void Insert(Node* &pRoot, Company x)
{
	if(pRoot == nullptr)
		pRoot = createNode(x);

	if(strcmp(pRoot->data.tax, x.tax)==0)
	{
		return;
	}
	else if(strcmp(pRoot->data.tax, x.tax)>0)
	{
		Insert(pRoot->pLeft, x);
	}
	else
	{
		Insert(pRoot->pRight, x);
	}
	MakeRightHeight(pRoot);
}
// void Remove(Node* &pRoot, int x)
// {
// 	if(pRoot == nullptr)
// 		return;

// 	if(pRoot->key > x)
// 	{
// 		Remove(pRoot->pLeft, x);
// 	}
// 	else if(pRoot->key < x)
// 	{
// 		Remove(pRoot->pRight, x);
// 	}
// 	else
// 	{
// 		if(pRoot->pLeft == nullptr && pRoot->pRight == nullptr)
// 		{
// 			delete pRoot;
// 			pRoot = nullptr;
// 		}
// 		else if(pRoot->pLeft != nullptr && pRoot->pRight == nullptr)
// 		{
// 			pRoot = pRoot->pLeft;
// 		}
// 		else if(pRoot->pLeft == nullptr && pRoot->pRight != nullptr)
// 		{
// 			pRoot = pRoot->pRight;
// 		}
// 		else if(pRoot->pLeft != nullptr && pRoot->pRight != nullptr)
// 		{
// 			Node* temp = pRoot->pRight;
// 			while(temp->pLeft != nullptr)
// 				temp = temp->pLeft;
// 			pRoot->key = temp->key;
// 			Remove(pRoot->pRight, temp->key);
// 		}
// 	}
// 	MakeRightHeight(pRoot);
// }

/*
Read file function
*/
FILE *fptr = nullptr;
Node* read_file(void* file_name) {
	// Convert file's name to char
	char* r_file = nullptr;
	r_file = (char*)file_name;

	// Open text file in reading mode
	fptr = fopen(r_file, "r");
	// Exit if cannot open file
	if(fptr == nullptr)
	{
		printf("Cannot open to read file");
		exit(1);
	}

	// Read file and create AVL tree
	char file_content[201]; // char string to read file
	Node* pRoot = nullptr;
	fgets(file_content, 201, fptr);

	// Read file
	while(fgets(file_content, 201, fptr))
	{
		// For each integer element
		char temp[201];
		int i_temp = 0;
		Company x;
		int x_data_index = 0;
		// cout << file_content << endl;
		// Covert read char into data
		for(int i = 0; i < strlen(file_content); i++)
		{
			if(file_content[i] != '|')
			{
				temp[i_temp++] = file_content[i];
				temp[i_temp++] = '\0';
			}
			if(file_content[i] == '|' || i+1==strlen(file_content))
			{
				if(x_data_index==0)
					strcpy(x.name, temp);
				else if(x_data_index==1)
					strcpy(x.tax, temp);
				else if(x_data_index==2)
					strcpy(x.legal_people, temp);
				else if(x_data_index==3)
					strcpy(x.address, temp);

				// cout << temp << " ";
				x_data_index++;
				i_temp = 0;
			}
		}
		Insert(pRoot, x);
	}

	return pRoot;
	// Close file
	fclose(fptr);
}

void name_search(Node* pRoot, char* name)
{
	if(pRoot == nullptr)
		return;

	if(strcmp(pRoot->data.name, name) == 0)
	{
		cout << pRoot->data.name << endl;
		cout << pRoot->data.tax << endl;
		cout << pRoot->data.legal_people << endl;
		cout << pRoot->data.address << endl;
		return;
	}

	if(pRoot->pLeft != nullptr)
	{
		name_search(pRoot->pLeft, name);
	}
	if(pRoot->pRight != nullptr)
	{
		name_search(pRoot->pRight, name);
	}
	return;
}

void tax_search(Node* pRoot, char* name)
{
	if(pRoot == nullptr)
		return;

	if(strcmp(pRoot->data.tax, name) == 0)
	{
		cout << pRoot->data.name << endl;
		cout << pRoot->data.tax << endl;
		cout << pRoot->data.legal_people << endl;
		cout << pRoot->data.address << endl;
		return;
	}

	if(pRoot->pLeft != nullptr)
	{
		name_search(pRoot->pLeft, name);
	}
	if(pRoot->pRight != nullptr)
	{
		name_search(pRoot->pRight, name);
	}
	return;
}

void LNR(Node* pRoot)
{
	if(pRoot == nullptr)
		return;

	if(pRoot->pLeft != nullptr)
	{
		LNR(pRoot->pLeft);
	}

	cout << pRoot->data.name << endl;
	cout << pRoot->data.tax << endl;
	cout << pRoot->data.legal_people << endl;
	cout << pRoot->data.address << endl;


	if(pRoot->pRight != nullptr)
	{
		LNR(pRoot->pRight);
	}
	return;
}

void tax_remove(Node* &pRoot, char* x)
{
	if(pRoot == nullptr)
		return;

	if(strcmp(pRoot->data.tax, x)>0)
	{
		tax_remove(pRoot->pLeft, x);
	}
	else if(strcmp(pRoot->data.tax, x)<0)
	{
		tax_remove(pRoot->pRight, x);
	}
	else
	{
		if(pRoot->pLeft == nullptr && pRoot->pRight == nullptr)
		{
			delete pRoot;
			pRoot = nullptr;
		}
		else if(pRoot->pLeft != nullptr && pRoot->pRight == nullptr)
		{
			pRoot = pRoot->pLeft;
		}
		else if(pRoot->pLeft == nullptr && pRoot->pRight != nullptr)
		{
			pRoot = pRoot->pRight;
		}
		else if(pRoot->pLeft != nullptr && pRoot->pRight != nullptr)
		{
			Node* temp = pRoot->pRight;
			while(temp->pLeft != nullptr)
				temp = temp->pLeft;

			strcpy(pRoot->data.tax, temp->data.tax);
			strcpy(pRoot->data.name, temp->data.name);
			strcpy(pRoot->data.legal_people, temp->data.legal_people);
			strcpy(pRoot->data.address, temp->data.address);

			tax_remove(pRoot->pRight, temp->data.tax);
		}
	}
	MakeRightHeight(pRoot);
}

void all_tax_change(Node* pRoot, char* name)
{
	if(pRoot == nullptr)
		return;

	if(strcmp(pRoot->data.tax, name) == 0)
	{
		cin.ignore();
		cout << "New company name: ";
		cin.getline(pRoot->data.name, 200);

		cin.ignore();
		cout << "New company tax: ";
		cin.getline(pRoot->data.tax, 200);
		
		cin.ignore();
		cout << "New company legel people: ";
		cin.getline(pRoot->data.legal_people, 200);

		cin.ignore();
		cout << "New company address: ";
		cin.getline(pRoot->data.address, 200);
		
		cin.ignore();
		return;
	}

	if(pRoot->pLeft != nullptr)
	{
		name_search(pRoot->pLeft, name);
	}
	if(pRoot->pRight != nullptr)
	{
		name_search(pRoot->pRight, name);
	}
	return;
}

int main()
{
	// 1. Store company information
	char* file_name = "Company.txt";
	Node* pRoot = nullptr;
	pRoot = read_file(file_name);

	// 2. Search company by name
	char company_name[201];
	cout << "Search by name, input company name: ";
	cin.getline(company_name, 200);
	name_search(pRoot, company_name);


	// 3. Search company by tax code
	char tax_code[201];
	cout << "Search by tax, input company name: ";
	cin.getline(tax_code, 200);
	// cin.ignore();
	name_search(pRoot, tax_code);


	// 4. Render companies by increasing tax code
	LNR(pRoot);

	// 6. Delete by tax code
	char tax_remove_code[201];
	cout << "Removed by company's tax code: ";
	cin.getline(tax_remove_code, 200);
	// cin.ignore();
	tax_remove(pRoot, tax_remove_code);

	// 7. Change company information based on tax code
	char tax_code_change[201];
	cout << "Change company by tax, input tax code: ";
	cin.getline(tax_code_change, 200);
	// cin.ignore();
	all_tax_change(pRoot, tax_code_change);

	return 0;
}