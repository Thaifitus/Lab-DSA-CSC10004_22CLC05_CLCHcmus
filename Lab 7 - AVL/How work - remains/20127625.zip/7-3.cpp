#include <iostream>

using namespace std;

struct Node{
	int key;
	Node* pLeft;
	Node* pRight;
};
Node* createNode(int data)
{
	Node* temp = new Node;
	temp->key = data;
	temp->pLeft = nullptr;
	temp->pRight = nullptr;
	return temp;
}
int Height(Node* pRoot)
{
	if(pRoot == nullptr)
		return 0;

	int lheight = Height(pRoot->pLeft);
	int rheight = Height(pRoot->pRight);
	if(lheight > rheight)
		return lheight + 1;
	else
		return rheight + 1;
}

void RightRotation(Node* &pRoot)
{
	if(pRoot == nullptr || pRoot->pLeft == nullptr && pRoot->pRight == nullptr)
		return;

	Node* temp = pRoot->pLeft;
	pRoot->pLeft = temp->pRight;
	temp->pRight = pRoot;
	pRoot = temp;
}
void LeftRotation(Node* &pRoot)
{
	if(pRoot == nullptr || pRoot->pLeft == nullptr && pRoot->pRight == nullptr)
		return;

	Node* temp = pRoot->pRight;
	pRoot->pRight = temp->pLeft;
	temp->pLeft = pRoot;
	pRoot = temp;
}
void MakeRightHeight(Node* &pRoot)
{
	if(pRoot == nullptr)
		return;

	int diff = Height(pRoot->pLeft) - Height(pRoot->pRight);
	int l, r;
	if(diff >= 2)
	{
		l = Height(pRoot->pLeft->pLeft);
		r = Height(pRoot->pLeft->pRight);
		if(l >= r)
		{
			RightRotation(pRoot);
		}
		else
		{
			LeftRotation(pRoot->pLeft);
			RightRotation(pRoot);
		}
	}
	else if(diff <= -2)
	{
		l = Height(pRoot->pRight->pLeft);
		r = Height(pRoot->pRight->pRight);
		if(r >= l)
		{
			LeftRotation(pRoot);
		}
		else
		{
			RightRotation(pRoot->pRight);
			LeftRotation(pRoot);
		}
	}
}
void Insert(Node* &pRoot, int x)
{
	if(pRoot == nullptr)
		pRoot = createNode(x);

	if(pRoot->key == x)
	{
		return;
	}
	else if(pRoot->key > x)
	{
		Insert(pRoot->pLeft, x);
	}
	else
	{
		Insert(pRoot->pRight, x);
	}
	MakeRightHeight(pRoot);
}
void Remove(Node* &pRoot, int x)
{
	if(pRoot == NULL)
		return;

	if(pRoot->key > x)
	{
		Remove(pRoot->pLeft, x);
	}
	else if(pRoot->key < x)
	{
		Remove(pRoot->pRight, x);
	}
	else
	{
		if(pRoot->pLeft == NULL && pRoot->pRight == NULL)
		{
			delete pRoot;
			pRoot = NULL;
		}
		else if(pRoot->pLeft != NULL && pRoot->pRight == NULL)
		{
			pRoot = pRoot->pLeft;
		}
		else if(pRoot->pLeft == NULL && pRoot->pRight != NULL)
		{
			pRoot = pRoot->pRight;
		}
		else if(pRoot->pLeft != NULL && pRoot->pRight != NULL)
		{
			Node* temp = pRoot->pRight;
			while(temp->pLeft != NULL)
				temp = temp->pLeft;
			pRoot->key = temp->key;
			Remove(pRoot->pRight, temp->key);
		}
	}
	MakeRightHeight(pRoot);
}

int level(Node* pRoot, Node* x)
{
	if(pRoot == nullptr || x == nullptr)
		return -1;

	int level = 1;
	Node* temp = pRoot;
	while(temp != nullptr)
	{
		if(temp->key < x->key)
		{
			temp = temp->pRight;
		}
		else if(temp->key > x->key)
		{
			temp = temp->pLeft;
		}
		else
		{
			if(temp != x)
			{
				level = -1;
			} 
			break;
		}
		level++;			
	}
	return level;
}
void NLR(Node* pRoot_org, Node* pRoot, int arr[], int& i)
{
	if(pRoot == NULL)
		return;

	if(pRoot->pLeft == nullptr && pRoot->pRight==nullptr)
	{
		arr[i++] = level(pRoot_org, pRoot);
	}
	if(pRoot->pLeft != NULL)
	{
		NLR(pRoot_org, pRoot->pLeft, arr, i);
	}
	if(pRoot->pRight != NULL)
	{
		NLR(pRoot_org, pRoot->pRight, arr, i);
	}
	return;
}


int main()
{
	Node* pRoot = nullptr; // Empty AVL tree
	int arr[6] = {10, 20, 30, 40, 50, 25}; // Data for AVL tree
	int res[6]; // array stores level of leaf nodes
	int res_index = 0;
	bool same_depth = true; // final result

	// Create AVL tree from data array
	for(int i = 0; i < 6; i++)
		Insert(pRoot, arr[i]);

	// Remove(pRoot, 50);
	// Find depth of each leaf node
	NLR(pRoot, pRoot, res, res_index);
	// Check whether all leafs have the same depth
	for(int i = 0; i < res_index - 1; i++)
	{
		if(res[i] != res[i+1])
		{
			same_depth = false;
			break;
		}
	}
	// Print result to console
	if(!same_depth)
		cout << "Leaf nodes don't have the same depth\n";
	else
		cout << "Leaf nodes have the same depth\n";

	// REMOVE NODE with key=50
	Remove(pRoot, 50);
	cout << "Removed node with key=50: ";
	// Find depth of each leaf node
	NLR(pRoot, pRoot, res, res_index);
	// Check whether all leafs have the same depth
	for(int i = 0; i < res_index - 1; i++)
	{
		if(res[i] != res[i+1])
		{
			same_depth = false;
			break;
		}
	}
	// Print result to console
	if(!same_depth)
		cout << "Leaf nodes don't have the same depth\n";
	else
		cout << "Leaf nodes have the same depth\n";

	return 0;
}