#include <iostream>
#include <string.h>

using namespace std;

struct Node{
	int key;
	Node* pLeft;
	Node* pRight;
};
Node* createNode(int data)
{
	Node* temp = new Node;
	temp->pLeft = nullptr;
	temp->pRight = nullptr;
	temp->key = data;
	return temp;
}
void Insert(Node* &pRoot, int x)
{
	if(pRoot == nullptr)
		pRoot = createNode(x);

	if(pRoot->key == x)
		return;
	else if(pRoot->key > x)
	{
		Insert(pRoot->pLeft, x);
	}
	else
		Insert(pRoot->pRight, x);
}
int Height(Node* pRoot)
{
	if(pRoot == nullptr)
		return 0;

	int lheight = Height(pRoot->pLeft);
	int rheight = Height(pRoot->pRight);
	if(lheight > rheight)
		return lheight + 1;
	else
		return rheight + 1;
}
bool isAVL(Node* pRoot)
{
	if(pRoot == nullptr)
		return true;

	int l_h = Height(pRoot->pLeft);
	int r_h = Height(pRoot->pRight);
	if(abs(l_h-r_h) <= 1 && isAVL(pRoot->pLeft) && isAVL(pRoot->pRight))
		return true;
	return false;
}
FILE *fptr_w = nullptr;
/*
Write to file function
*/
void write_file(void* file_name, char** input, int tree_count) {
	// Convert file's name to char
	char *w_file = nullptr;
    w_file = (char*)file_name;

    // Open text file in writing mode
    fptr_w = fopen(w_file, "w");
    // Exit if cannot open file
    if(fptr_w == nullptr)
    {
        printf("Cannot open to write file");
        exit(1);
    }

    // Write to file
    // char input[100];
    for(int i = 0; i < tree_count; i++)
    {
    	fprintf(fptr_w, "%s\n", input[i]);
    }
    
    // Close file
    fclose(fptr_w);
}

FILE *fptr = nullptr;
/*
Read file function
*/
void read_file(void* file_name) {
	// Convert file's name to char
	char* r_file = nullptr;
	r_file = (char*)file_name;

	// Open text file in reading mode
	fptr = fopen(r_file, "r");
	// Exit if cannot open file
	if(fptr == nullptr)
	{
		printf("Cannot open to read file");
		exit(1);
	}

	char file_content[201]; // char string to read file
	int tree_count = 0; // number of tree

	fgets(file_content, 201, fptr);
	// Write result
	tree_count = atoi(file_content);
	char** write_result = new char*[tree_count];
	int write_result_i = 0;
	// Read file
	while(fgets(file_content, 201, fptr))
	{
		// cout << file_content << endl;
		// BST tree
		Node* pRoot = nullptr;
		// For each integer element
		char temp[201];
		int i_temp = 0;
		// Covert char to int and insert to BST tree
		for(int i = 0; i < strlen(file_content); i++)
		{
			if(file_content[i] != ' ')
			{
				temp[i_temp++] = file_content[i];
				temp[i_temp++] = '\0';
			}
			if(file_content[i] == ' ' || i+1==strlen(file_content))
			{
				Insert(pRoot, atoi(temp));
				i_temp = 0;
			}
		}

		write_result[write_result_i] = new char[4];
		if(isAVL(pRoot))
			strcpy(write_result[write_result_i++], "yes");
		else
			strcpy(write_result[write_result_i++], "no");
	}
	// Write result to file "Output.txt"
	char* w_file_name = "Output.txt";
	write_file(w_file_name, write_result, tree_count);

	// Close file
	fclose(fptr);
}


int main()
{
	char* file_name = "input.txt";
	read_file(file_name);

	return 0;
}