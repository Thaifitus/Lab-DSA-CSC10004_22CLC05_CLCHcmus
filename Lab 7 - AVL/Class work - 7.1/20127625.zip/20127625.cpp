#include <iostream>

using namespace std;

// 1. Create data structure for AVL Tree
struct Node{
	int key;
	Node* pLeft;
	Node* pRight;
};


Node* createNode(int data)
{
	Node* temp = new Node;
	temp->key = data;
	temp->pLeft = nullptr;
	temp->pRight = nullptr;
	return temp;
}
int Height(Node* pRoot)
{
	if(pRoot == nullptr)
		return -1;

	int lheight = Height(pRoot->pLeft);
	int rheight = Height(pRoot->pRight);
	if(lheight > rheight)
		return lheight + 1;
	else
		return rheight + 1;
}
void RightRotation(Node* &pRoot)
{
	if(pRoot == nullptr || pRoot->pLeft == nullptr && pRoot->pRight == nullptr)
		return;

	Node* temp = pRoot->pLeft;
	pRoot->pLeft = temp->pRight;
	temp->pRight = pRoot;
	pRoot = temp;
}
void LeftRotation(Node* &pRoot)
{
	if(pRoot == nullptr || pRoot->pLeft == nullptr && pRoot->pRight == nullptr)
		return;

	Node* temp = pRoot->pRight;
	pRoot->pRight = temp->pLeft;
	temp->pLeft = pRoot;
	pRoot = temp;
}
void MakeRightHeight(Node* &pRoot)
{
	if(pRoot == nullptr)
		return;

	int diff = Height(pRoot->pLeft) - Height(pRoot->pRight);
	int l, r;
	if(diff >= 2)
	{
		l = Height(pRoot->pLeft->pLeft);
		r = Height(pRoot->pLeft->pRight);
		if(l >= r)
		{
			RightRotation(pRoot);
		}
		else
		{
			LeftRotation(pRoot->pLeft);
			RightRotation(pRoot);
		}
	}
	else if(diff <= -2)
	{
		l = Height(pRoot->pRight->pLeft);
		r = Height(pRoot->pRight->pRight);
		if(r >= l)
		{
			LeftRotation(pRoot);
		}
		else
		{
			RightRotation(pRoot->pRight);
			LeftRotation(pRoot);
		}
	}
}
void Insert(Node* &pRoot, int x)
{
	if(pRoot == nullptr)
		pRoot = createNode(x);

	if(pRoot->key == x)
	{
		return;
	}
	else if(pRoot->key > x)
	{
		Insert(pRoot->pLeft, x);
	}
	else
	{
		Insert(pRoot->pRight, x);
	}
	MakeRightHeight(pRoot);
}

// Pre-order
void NLR(Node* pRoot)
{
	if(pRoot == nullptr)
		return;

	cout << pRoot->key << " ";
	if(pRoot->pLeft != nullptr)
	{
		NLR(pRoot->pLeft);
	}
	if(pRoot->pRight != nullptr)
	{
		NLR(pRoot->pRight);
	}
	return;
}
// In-order
void LNR(Node* pRoot)
{
	if(pRoot == nullptr)
		return;

	if(pRoot->pLeft != nullptr)
	{
		LNR(pRoot->pLeft);
	}
	cout << pRoot->key << " ";
	if(pRoot->pRight != nullptr)
	{
		LNR(pRoot->pRight);
	}
	return;
}
// Post order
void LRN(Node* pRoot)
{
	if(pRoot == nullptr)
		return;

	if(pRoot->pLeft != nullptr)
	{
		LRN(pRoot->pLeft);
	}
	if(pRoot->pRight != nullptr)
	{
		LRN(pRoot->pRight);
	}
	cout << pRoot->key << " ";
	return;
}

// Remove a value from tree
void Remove(Node* &pRoot, int x)
{
	if(pRoot == nullptr)
		return;

	if(pRoot->key > x)
	{
		Remove(pRoot->pLeft, x);
	}
	else if(pRoot->key < x)
	{
		Remove(pRoot->pRight, x);
	}
	else
	{
		if(pRoot->pLeft == nullptr && pRoot->pRight == nullptr)
		{
			delete pRoot;
			pRoot = nullptr;
		}
		else if(pRoot->pLeft != nullptr && pRoot->pRight == nullptr)
		{
			pRoot = pRoot->pLeft;
		}
		else if(pRoot->pLeft == nullptr && pRoot->pRight != nullptr)
		{
			pRoot = pRoot->pRight;
		}
		else if(pRoot->pLeft != nullptr && pRoot->pRight != nullptr)
		{
			Node* temp = pRoot->pRight;
			while(temp->pLeft != nullptr)
				temp = temp->pLeft;
			pRoot->key = temp->key;
			Remove(pRoot->pRight, temp->key);
		}
	}
	MakeRightHeight(pRoot);
}

// Search value
Node* Search(Node* &pRoot, int x)
{
	if(pRoot == NULL)
		return nullptr;

	if(pRoot->key == x)
		return pRoot;
	else if(pRoot->key > x)
		return Search(pRoot->pLeft, x);
	else
		return Search(pRoot->pRight, x);
}

int main(int argc, char *argv[])
{
	// User's selected function
	int selection = 0;
	// 2. Initialize empty tree
	Node* pRoot = nullptr;
	cout << "-------------FUNCTIONS-------------\n";
	cout << "1. Insert a value to tree\n";
	cout << "2. Print tree to console screen in pre-order\n";
	cout << "3. Print tree to console screen in in-order\n";
	cout << "4. Print tree to console screen in post-order\n";
	cout << "5. Delete a value from tree\n";
	cout << "6. Calculate tree height\n";
	cout << "7. Identify whether a given value is exist in tree\n";

	while(cin >> selection)
	{
		switch(selection)
		{
		case 1:
			{
				int insert_value = 0;
				cout << "Inserted value: ";
				cin >> insert_value;
				Insert(pRoot, insert_value);
				cout << "Inserted successfully\n";
				break;
			}
		case 2:
			{
				NLR(pRoot);
				break;
			}	
		case 3:
			{
				LNR(pRoot);
				break;
			}	
		case 4:
			{
				LRN(pRoot);
				break;
			}	
		case 5:
			{
				int del_value = 0;
				cout << "Delete value: ";
				cin >> del_value;
				Remove(pRoot, del_value);
				cout << "Delete successfully\n";
				break;
			}	
		case 6:
			{
				cout << "Tree's height: " << Height(pRoot) << endl;
				break;
			}	
		case 7:
			{
				int found_value = 0;
				cout << "Found value: ";
				cin >> found_value;
				Node* res = Search(pRoot, found_value);
				if(res == nullptr)
					cout << "Value doesn't exist in tree";
				else
					cout << "Value exist in tree";
				break;
			}	
		default:
			{
				cout << "Invalid selection\n";
			}
		}
		cout << endl;
	}
	return 0;
}