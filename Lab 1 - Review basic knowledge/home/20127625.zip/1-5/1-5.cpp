#include <iostream>
#include <string.h>
#include <stdio.h>

using namespace std;

FILE *fptr = NULL;
int file_line = 0; // 1st line of file is 1 (not 0)

/*
Count lines of file
*/
void count_line(void* file_name)
{
	// Convert file's name to char
	char* r_file = NULL;
	r_file = (char*)file_name;
	// Open text file in reading mode
	fptr = fopen(r_file, "r");
	// Exit if cannot open file
	if(fptr == NULL)
	{
		printf("Cannot open to read file");
		exit(1);
	}

	char file_content[201];
	while(fgets(file_content, sizeof(file_content), fptr))
	{
		file_line++;
	}

	fclose(fptr);
}
/*
Read file function
*/
void read_file(int select, int n, void* file_name) {
	if(n<=0)
	{
		cout << "Invalid n";
		return;
	}

	// Convert file's name to char
	char* r_file = NULL;
	r_file = (char*)file_name;
	// Open text file in reading mode
	fptr = fopen(r_file, "r");
	// Exit if cannot open file
	if(fptr == NULL)
	{
		printf("Cannot open to read file");
		exit(1);
	}

	// Read file (line counted from 1 (not from 0))
	char file_content[201];
	int i = 1;
	while(fgets(file_content, sizeof(file_content), fptr))
	{
		switch (select)
		{
		case 0:
			{
				if(i <= n)
					cout << file_content;
				break;
			}
		case 1:
			{
				if(i >= file_line - n + 1)
					cout << file_content;
				break;
			}
		}
		i++;
	}

	// Close file
	fclose(fptr);
}

int main()
{
	char file_name[201];
	int select, n;

	// Input
	cout << "First argument (0 or 1): ";
	cin >> select;
	cout << "Positive integer n: ";
	cin >> n;
	cout << "File's name: ";
	cin >> file_name;

	count_line(file_name);
	read_file(select, n, file_name);

	return 0;
}