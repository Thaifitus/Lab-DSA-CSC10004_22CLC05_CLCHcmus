#include <iostream>
#include <fstream>
#include <string.h>

using namespace std;

struct Student {
   char name[201];
   char birth[201];
   char address[201];
   char clas[201];
   char id[201];
};

void read_binary_file(void* file_name, int n) {
   // Convert file's name to char
   char* r_file = NULL;
   r_file = (char*)file_name;
   // Open file for writing
   ifstream rf(r_file, ios::out | ios::binary);
   if(!rf)
   {
      cout << "Cannot open file!";
      exit(1);
   }
   
   // Read file
   Student** rstu = new Student*[n];
   for(int i = 0; i < n; i++)
   {
      rstu[i] = new Student;
      rf.read((char *) &rstu[i], sizeof(Student));
   }
   
   // Close file
   rf.close();
   if(!rf.good()) {
      cout << "Error occurred at reading time!" << endl;
      exit(1);
   }

   // Display student
   for(int i = 0; i < n; i++)
   {
      cout << rstu[i]->name << endl;
      cout << rstu[i]->birth << endl;
      cout << rstu[i]->address << endl;
      cout << rstu[i]->clas << endl;
      cout << rstu[i]->id << endl;    
   }
}


int main()
{
   int so_luong_student = 0;
   cout << "So luong student: ";
   cin >> so_luong_student;

   char file_name[] = "output1.9.bin";
   read_binary_file(file_name, so_luong_student);

   return 0;
}