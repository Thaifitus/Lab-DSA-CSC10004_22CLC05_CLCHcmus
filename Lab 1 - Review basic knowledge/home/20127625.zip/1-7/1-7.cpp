#include <iostream>
#include <string.h>
#include <stdio.h>

using namespace std;

struct Node {
	int data;
	Node* pNext;
};
// 1. INITIALIZE A Node FROM A GIVEN DATA
Node* createNode(int data)
{
	Node* res = new Node;
	res->pNext = nullptr;
	res->data = data;
	return res;
}

struct Queue // FIFO _ add tail, remove head 
{
	Node* pHead;
	Node* pTail;
};
// INITIALIZE A QUEUE FROM A GIVEN KEY
Queue* IniQueue(int data)
{
	Queue* Q = new Queue;
	Q->pHead = createNode(data);
	Q->pTail = Q->pHead;
	return Q;
}
// ENQUEUE A KEY INTO A GIVEN QUEUE
void Enqueue(Queue* &Q, int data)
{
	if(Q == nullptr)
	{
		Q = IniQueue(data);
	}
	else
	{
		Node* temp = createNode(data);
		if(Q->pHead == nullptr)
		{
			Q->pHead = temp;
			Q->pTail = temp;
		}
		else
		{
			Q->pTail->pNext = temp;
			Q->pTail = temp;
		}
	}
}
// DEQUEUE AN ELEMENT OUT OF A GIVEN QUEUE
bool Dequeue(Queue* &Q)
{
	if(Q == nullptr || Q->pHead == nullptr)
		return false;

	Node* temp = Q->pHead;
	if(Q->pHead == Q->pTail) // Queue has 1 element
	{
		Q->pHead = nullptr;
		Q->pTail = nullptr;
	}
	else
	{
		Q->pHead = Q->pHead->pNext;
	}
	delete temp;
	return true;
}
// DETERMINE IF A GIVEN queue IS EMPTY
bool IsQueueEmpty(Queue* Q)
{
	if(Q == nullptr || Q->pHead == nullptr)
		return true;
	return false;
}
// COUNT THE NUMBER OF ELEMENTS OF A GIVEN queue
bool QueueSize(Queue* Q)
{
	if(IsQueueEmpty(Q))
	{
		cout << "Queue hien dang rong (empty)\n";
		return true;
	}
	cout << "----------Queue HIEN TAI----------\n";
	Node* temp = Q->pHead;
	while(temp != nullptr)
	{
		cout << temp->data << endl;
		temp = temp->pNext;
	}
	return true;
}


int main()
{
	Queue* Q = nullptr;
	int select;
	cout << "Phuong thuc queue\n1 = Enqueue\n2 = Dequeue\n";
	while(cin >> select)
	{
		switch (select)
		{
		case 1:
			{
				cout << "So nguyen dau vao: ";
				int data;
				cin >> data;
				Enqueue(Q, data);
				break;
			}
		case 2:
			{
				Dequeue(Q);
				break;
			}
		default:
			{
				cout << "Lua chon khong hop le";
			}
		}
		QueueSize(Q);
		cout << "\nPhuong thuc: ";
	}
	return 0;
}