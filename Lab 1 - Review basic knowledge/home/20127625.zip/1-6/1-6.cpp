#include <iostream>
#include <string.h>
#include <stdio.h>

using namespace std;

struct Node {
	char data[201];
	Node* pNext;
};
// 1. INITIALIZE A Node FROM A GIVEN DATA
Node* createNode(char* data)
{
	Node* res = new Node;
	res->pNext = nullptr;
	strcpy(res->data, data);
	return res;
}

struct Stack // LIFO _ add head, remove head
{
	Node* pHead;
};
// INITIALIZE A STACK FROM A GIVEN data
Stack* IniStack(char* data)
{
	Stack* S = new Stack;
	S->pHead = createNode(data);
	return S;
}
// PUSH A data INTO A GIVEN STACK
void Push(Stack* &S, char* data)
{
	if(S == nullptr)
	{
		S = IniStack(data);
	}
	else
	{
		Node* temp = createNode(data);
		temp->pNext = S->pHead;
		S->pHead = temp;
	}
}
// POP AN ELEMENT OUT OF A GIVEN STACK, RETURN THE data'S VALUE
bool Pop(Stack* &S)
{
	if(S == nullptr)
		return false;
	if(S != nullptr && S->pHead != nullptr)
	{
		Node* temp = S->pHead;
		if(S->pHead->pNext == nullptr) // Stack has 1 element
		{
			S->pHead = nullptr;
		}
		else
		{
			S->pHead = S->pHead->pNext;
		}
		delete temp;
		return true;
	}
	return false;
}
// DETERMINE IF A GIVEN STACK IS EMPTY
bool IsStackEmpty(Stack* S)
{
	if(S == nullptr || S->pHead == nullptr)
		return true;
	return false;
}
// COUNT THE NUMBER OF ELEMENTS OF A GIVEN STACK
bool StackSize(Stack* S)
{
	if(IsStackEmpty(S))
	{
		cout << "Stack hien dang rong (empty)";
		return true;
	}
	cout << "----------STACK HIEN TAI----------\n";
	Node* temp = S->pHead;
	while(temp != nullptr)
	{
		cout << temp->data;
		temp = temp->pNext;
	}
	return true;
}


int main()
{
	Stack* S = nullptr;
	int select;
	cout << "Phuong thuc stack\n1 = push\n2 = pop\n";
	while(cin >> select)
	{
		switch (select)
		{
		case 1:
			{
				cout << "Ky tu (chuoi) dau vao: ";
				char input_str[201];
				cin.ignore();
				fgets(input_str, sizeof(input_str), stdin);
				Push(S, input_str);
				break;
			}
		case 2:
			{
				Pop(S);
				break;
			}
		default:
			{
				cout << "Lua chon khong hop le";
			}
		}
		StackSize(S);
		cout << "\nPhuong thuc: ";
	}
	return 0;
}