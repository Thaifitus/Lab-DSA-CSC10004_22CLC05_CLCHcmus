#include <iostream>
#include <fstream>
#include <string.h>

using namespace std;

struct Student {
   char name[201];
   char birth[201];
   char address[201];
   char clas[201];
   char id[201];
};

/*
Reference: https://www.tutorialspoint.com/reading-and-writing-binary-file-in-c-cplusplus
*/
void write_binary_file(void* file_name, Student** data, int n) {
   // Convert file's name to char
   char* r_file = NULL;
   r_file = (char*)file_name;
   // Open file for writing
   ofstream wf(r_file, ios::out | ios::binary);
   if(!wf)
   {
      cout << "Cannot open file!";
      exit(1);
   }

   // Write to file
   for(int i = 0; i < n; i++)
   {
      wf.write((char *) &*data[i], sizeof(Student));
   }

   // Close file
   wf.close();
   if(!wf.good())
   {
      cout << "Error occurred at writing time!";
      exit(1);
   }
}


int main()
{
   int so_luong_student = 0;
   cout << "So luong student: ";
   cin >> so_luong_student;
   cin.ignore();

   Student** data = new Student*[so_luong_student];
   for(int i = 0; i < so_luong_student; i++)
   {
      data[i] = new Student;

      // Nguoi dung nhap ho ten hoc sinh
      cout << "\nHo ten: ";
      fgets(data[i]->name, sizeof(data[i]->name), stdin);
      data[i]->name[strcspn(data[i]->name, "\n")] = 0;
      // Nguoi dung nhap ngay sinh
      cout << "Ngay thang nam sinh: ";
      fgets(data[i]->birth, sizeof(data[i]->birth), stdin);
      data[i]->birth[strcspn(data[i]->birth, "\n")] = 0;
      // Nguoi dung nhap dia chi
      cout << "Dia chi cu tru: ";
      fgets(data[i]->address, sizeof(data[i]->address), stdin);
      data[i]->address[strcspn(data[i]->address, "\n")] = 0;
      // Nguoi dung nhap lop hoc
      cout << "Ma lop hoc: ";
      fgets(data[i]->clas, sizeof(data[i]->clas), stdin);
      data[i]->clas[strcspn(data[i]->clas, "\n")] = 0;
      // Nguoi dung nhap ID hoc sinh
      cout << "ID: ";
      fgets(data[i]->id, sizeof(data[i]->id), stdin);
      data[i]->id[strcspn(data[i]->id, "\n")] = 0;
   }

   char file_name[] = "output1.9.bin";
   write_binary_file(file_name, data, so_luong_student);

   return 0;
}