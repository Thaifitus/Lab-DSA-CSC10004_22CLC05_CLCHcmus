#include <iostream>
#include <string.h>

using namespace std;

FILE *fptr = nullptr;

/*
Formating (remove not alphabet characters, convert to lowercase) input string
Reference: geeksforgeeks
*/
char* format_char(char str[])
{
	// To keep track of non-space character count
    int count = 0;
    char* res = new char[strlen(str) + 1];
 
    // Traverse the given string. If current character is alphabet, then place it at index 'count++'
    for (int i = 0; i < strlen(str); i++)
    {
    	if ((str[i] >= 65 && str[i] <= 90) || (str[i] >= 97 && str[i] <= 122))
    	{
    		res[count++] = str[i];
		// res[count]=  '\0';
    	}
    }
    res[count] = '\0';

    // Convert upper case to lower case
    for(int i = 0; i < strlen(res); i++)
    { 
    	if(res[i] >= 65 && res[i] <= 90)
    	{
    		res[i] = res[i]+32;
    	}
    }
    return res;
}
/*
Check if input string is palindfrome or not
*/
bool is_palindrome(char str[])
{
	bool res = true;
	int n = strlen(str) / 2;
	for(int i = 0; i < n; i++)
	{
		if(str[i] != str[strlen(str) - 1 - i])
		{
			res = false;
			break;
		}
	}
	return res;
}
/*
Read file function
*/
void read_file(void* file_name) {
	// Convert file's name to char
	char* r_file = nullptr;
	r_file = (char*)file_name;

	// Open text file in reading mode
	fptr = fopen(r_file, "r");
	// Exit if cannot open file
	if(fptr == nullptr)
	{
		printf("Cannot open to read file");
		exit(1);
	}

	char file_content[201];
	// Read file
	while(fgets(file_content, sizeof(file_content), fptr))
	{
		file_content[strcspn(file_content, "\n")] = 0;
		char* temp = format_char(file_content);
		if(!is_palindrome(temp))
		{
			cout << file_content << " is not a palindrome";
		}
		else
		{
			cout << file_content << " is a palindrome";
		}
		cout << endl;
	}

	// Close file
	fclose(fptr);
}


int main()
{
	char file_name[] = "input1.8.1.txt";
	read_file(file_name);

	return 0;
}